package io.spring.json.parse.db.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import io.spring.json.parse.db.entities.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {

	@Modifying
	@Query(value = "ALTER TABLE user_entity ADD COLUMN APU_ID VARCHAR(255)", nativeQuery = true)
	void findAllUsingNativeQuery();

}
